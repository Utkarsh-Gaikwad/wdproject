<?php
include'connection.php';
session_start();

if (isset($_POST['submit'])){
    $lname = mysqli_real_escape_string($con,$_POST['username']);
    $lpassword = mysqli_real_escape_string($con,$_POST['password']);

    $select = "SELECT * FROM signupinfo WHERE username='$lname' AND password='$lpassword'";
    $result= mysqli_query($con,$select);

    if(mysqli_num_rows($result)>0){
        $row= mysqli_fetch_array($result);
        $_SESSION['id']=$row['id'];
        header('location:ocr.php');
    }
    else{
        $error='User Not Registered';
    }

}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="login.css" />
  </head>
<body>
    <?php
    include "nav1.html";
    ?>
    <div class="main">
        <div class="login-im">
            <img src="wefwfe.gif" alt="" style="width: 80%;" />

        </div>
        <div class="login-box">
            <h2>Login Here</h2>
            <form method="POST">
                <?php
        if (isset($error)){
            echo $error;
        }
                ?>

                <label>Username:</label>
                <input type="text" name="username" placeholder="Enter username" /><br />

                <label>Password:</label>
                <input type="password" name="password" placeholder="Enter password" />
                <br />
                <a href="signup.php">Sign Up</a>
                <br />
                <br />

                <input type="submit" name="submit" value="Login" /><br />
            </form>
        </div>
    </div>
    <?php
    include "footer.html";
    ?>
</body>
</html>
