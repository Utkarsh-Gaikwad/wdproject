<?php

$con = mysqli_connect('localhost','root','','ocr_db');
if(mysqli_connect_error()){
    echo"<H1>Connection Error</H1>";
}


?>