<?php

?>
<!DOCTYPE html>
<html>
<head>
    <title>UPAH</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="index.css" />
    <style>
      .container {
        display: flex;
        align-items: center;
        justify-content: center;
      }

      img {
        max-width: 100%;
        max-height: 100%;
      }

      .text {
        font-size: 20px;
        padding-left: 20px;
      }
    </style>
</head>
<body>
    <?php
    include "nav1.html";
    ?>
    <main>
        <section id="hero" class="d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="container">
                        <div class="text">
                            <h1>OCR ONLINE! Fast and Efficient! </h1>
                            <h2>
                                <i>
                                    Our free online OCR service allows you to quickly and easily convert scanned documents and images into editable text, with no limits on the number of files you can upload. There's no need to install any software, making it easy to start using our OCR service right away.Try it now and see how our OCR service can make your life easier!
                                </i>
                            </h2>
                        </div>
                        <div>
                            <img class="image" src="wfewfe.gif" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php
    include "footer.html";
    ?>
</body>
</html>