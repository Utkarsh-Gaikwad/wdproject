const form = document.querySelector("form");

form.addEventListener("submit", function (e) {
  e.preventDefault();
  const username = form.username.value;
  const password = form.password.value;

  //if (username === "user" && password === "pass") {
    //alert("Login Successful!");
    //window.location.href = "ocr.html";
  //} else {
   // alert("Invalid username or password!");
  //}
});
