<?php
include 'connection.php';
session_start();
if(!isset($_SESSION['id']))
{
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>OCR</title>
    <link rel="stylesheet" type="text/css" href="ocr.css" />
  </head>
  <body>
      <?php
      include "nav2.html";
      ?>

    <div>
    <h2>Upload your Image</h2>
    </div>
    <div>
      <input type="file" id="fileInput" onchange="displayImage(event)" />
    </div>
    <div>
      <img id="imagePreview" src="preview.jpg" alt="Image Preview" />
    </div>

    <div><button id="recognizeBtn">Recognize Text</button></div>

    <div id="output"></div>

    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs-core@3.7.0/dist/tf-core.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs-backend-cpu@3.7.0/dist/tf-backend-cpu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs-backend-webgl@3.7.0/dist/tf-backend-webgl.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tesseract.js@2.1.4/dist/tesseract.min.js"></script>
      
    <script>
      function displayImage(event) {
        var image = document.getElementById("imagePreview");
        image.src = URL.createObjectURL(event.target.files[0]);
      }

      const fileInput = document.getElementById("fileInput");
      const recognizeBtn = document.getElementById("recognizeBtn");
      const outputDiv = document.getElementById("output");

      recognizeBtn.addEventListener("click", () => {
        Tesseract.recognize(fileInput.files[0], "eng", {
          logger: (m) => console.log(m),
        }).then(({ data: { text } }) => {
          outputDiv.innerHTML = text;
        });
      });
    </script>

    <?php
    include "footer.html";
    ?>
  </body>
</html>
