<?php
include'connection.php';
session_start();


if(isset($_POST['register'])){
    $name = mysqli_real_escape_string($con,$_POST['name']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $password = mysqli_real_escape_string($con,$_POST['password']);
    $select = "SELECT * FROM signupinfo WHERE email='$email'";
    $result= mysqli_query($con,$select);

    if(mysqli_num_rows($result)>0){
        $error='User Already Registered';
    }
    else{
        $insert="INSERT INTO signupinfo(username,email,password) VALUES('$name','$email','$password')";
        mysqli_query($con,$insert);
        header('location:login.php');
    }
}

?>

<!DOCTYPE html>
<html>
  <head>
    <title>Sign Up Page</title>
      <link rel="stylesheet" type="text/css" href="signup.css" />
  </head>
  <body>
      <?php
      include "nav1.html";
      ?>
    <h1>Sign Up</h1>
    <form id="signup-form" method="POST">
        <?php
        if (isset($error)){
            echo "$error";
        }
        ?>
      <div>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required />
      </div>
      <div>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required />
      </div>
      <div>
        <button type="submit" name="register">Sign Up</button>
      </div>
    </form>
      <?php
      include "footer.html";
      ?>
  </body>
</html>

